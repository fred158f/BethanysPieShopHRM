﻿namespace KyllingCo.UI.Pages
{
    public partial class ShiftEdit
    {

    }
}
