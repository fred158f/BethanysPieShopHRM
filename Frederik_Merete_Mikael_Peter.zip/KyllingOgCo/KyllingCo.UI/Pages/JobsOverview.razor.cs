﻿using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using KyllingCo.UI.Components;
using KyllingCo.UI.Services;
using KyllingCo.Shared;
using Microsoft.AspNetCore.Components;

namespace KyllingCo.UI.Pages
{
    public class JobsOverviewBase: ComponentBase
    {
        [Inject]
        public IJobDataService JobService { get; set; }

        public List<Job> Jobs { get; set; }


        protected override async Task OnInitializedAsync()
        {
            Jobs = (await JobService.GetAllJobs()).ToList();
        }
    }
}
