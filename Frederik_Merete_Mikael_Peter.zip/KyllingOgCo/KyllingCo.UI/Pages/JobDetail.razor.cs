﻿using System.Collections.Generic;
using System.Threading.Tasks;
using KyllingCo.ComponentsLibrary.Map;
using KyllingCo.UI.Services;
using KyllingCo.Shared;
using Microsoft.AspNetCore.Components;

namespace KyllingCo.UI.Pages
{
    public class JobDetailBase : ComponentBase
    {
        [Inject]
        public IJobDataService JobDataService { get; set; }

        [Parameter]
        public int Id { get; set; }
       
        public Job Job { get; set; } = new Job();

        protected override async Task OnInitializedAsync()
        {
            Job = await JobDataService.GetJobById(Id);
        }
    }
}
