﻿using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using KyllingCo.UI.Components;
using KyllingCo.UI.Services;
using KyllingCo.Shared;
using Microsoft.AspNetCore.Components;
using Blazor.FlexGrid.DataAdapters;

namespace KyllingCo.UI.Pages
{
    public class ExpenseOverviewBase: ComponentBase
    {
        [Inject]
        public IExpenseDataService ExpenseService { get; set; }

        public CollectionTableDataAdapter<Expense> Expenses { get; set; }


        protected override async Task OnInitializedAsync()
        {
            var data = (await ExpenseService.GetAllExpenses()).ToList();
            Expenses = new CollectionTableDataAdapter<Expense>(data);
        }
    }
}
