﻿using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using KyllingCo.UI.Components;
using KyllingCo.UI.Services;
using KyllingCo.Shared;
using Microsoft.AspNetCore.Components;

namespace KyllingCo.UI.Pages
{
    public class StaffDirectoryBase: ComponentBase
    {
        [CascadingParameter(Name = "User")]
        public Employee CurrentUser { get; set; }

        [Inject]
        public IEmployeeDataService EmployeeDataService { get; set; }

        public List<Employee> Employees { get; set; }

        protected AddEmployeeDialog AddEmployeeDialog { get; set; }

        protected override async Task OnInitializedAsync()
        {
            Employees = (await EmployeeDataService.GetAllEmployees()).ToList();
        }

        public void UpdateButtons(int employeeId)
        {

        }
    }
}
