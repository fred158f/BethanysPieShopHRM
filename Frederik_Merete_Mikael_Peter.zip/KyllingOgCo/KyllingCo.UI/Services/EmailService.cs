﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using KyllingCo.Shared;

namespace KyllingCo.UI.Services
{
    public class EmailService : IEmailService
    {
        public void SendEmail()
        {
            // Todo: Send emails
        }
    }
}
