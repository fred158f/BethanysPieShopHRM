﻿namespace KyllingCo.UI.Services
{
    public class SwapService
    {
        private int currentUserId;

        public SwapService(int id)
        {
            currentUserId= id;
        }


        public void CreateSwap(int id)
        {

        }

    }
}
