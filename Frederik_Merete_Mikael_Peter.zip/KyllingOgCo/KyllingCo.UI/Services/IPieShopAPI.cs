﻿namespace KyllingCo.UI.Services
{
    internal interface IPieShopAPI
    {
    }
}