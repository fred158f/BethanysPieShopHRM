﻿namespace KyllingCo.UI.Services
{
    internal interface IRecruitingAPI
    {
    }
}