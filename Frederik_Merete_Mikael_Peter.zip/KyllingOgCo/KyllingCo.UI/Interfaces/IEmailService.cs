﻿using KyllingCo.Shared;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace KyllingCo.UI.Services
{
    public interface IEmailService
    {
        void SendEmail();
    }
}
