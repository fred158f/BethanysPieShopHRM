﻿using KyllingCo.Shared;
using System.Threading.Tasks;

namespace KyllingCo.UI.Services
{
    public interface IExpenseApprovalService
    {
        Task<ExpenseStatus> GetExpenseStatus(Expense expense);
    }
}