﻿using System.Collections.Generic;
using KyllingCo.Shared;

namespace KyllingCo.Api.Models
{
    public interface IJobCategoryRepository
    {
        IEnumerable<JobCategory> GetAllJobCategories();
        JobCategory GetJobCategoryById(int jobCategoryId);
    }
}
