﻿using System.Collections.Generic;
using KyllingCo.Shared;

namespace KyllingCo.Api.Models
{
    public interface ISurveyRepository
    {
        void AddAnswer(Answer answer);
        Survey AddSurvey(Survey survey);
        IEnumerable<Survey> GetAllSurveys();
        Survey GetSurveyById(int id);
    }
}