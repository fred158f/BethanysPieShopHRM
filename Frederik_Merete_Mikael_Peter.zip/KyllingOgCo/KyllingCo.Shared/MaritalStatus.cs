﻿namespace KyllingCo.Shared
{
    public enum MaritalStatus
    {
        Married,
        Single,
        Other
    }
}