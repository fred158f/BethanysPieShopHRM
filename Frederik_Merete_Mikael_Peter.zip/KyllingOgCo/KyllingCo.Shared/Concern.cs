﻿using System;
using System.Collections.Generic;
using System.Text;

namespace KyllingCo.Shared
{
    public class Concern
    {
        public int ConcernId { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }
    }
}
