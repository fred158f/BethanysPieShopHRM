﻿namespace KyllingCo.Shared
{
    public enum Gender
    {
        Male,
        Female,
        Other
    }
}
