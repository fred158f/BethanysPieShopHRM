﻿using System;
using System.Collections.Generic;
using System.Text;

namespace KyllingCo.Shared.Models
{
    public class WeekClass
    {
        public List<CalendarDay> Dates { get; set; } = new List<CalendarDay>();
    }
}
